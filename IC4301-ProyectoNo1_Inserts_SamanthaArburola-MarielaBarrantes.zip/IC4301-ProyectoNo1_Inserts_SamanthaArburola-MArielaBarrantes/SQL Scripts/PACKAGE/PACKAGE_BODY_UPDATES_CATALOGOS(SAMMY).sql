CREATE OR REPLACE PACKAGE BODY UPDATES_CATALOGO IS

       PROCEDURE UPDATE_CATALOGO_CIUDAD(pCiudad IN VARCHAR2)
         AS
                 BEGIN
                 END;

       PROCEDURE UPDATE_CATALOGO_EDAD(pRango IN VARCHAR2)
         AS
                 BEGIN
                 END;

       PROCEDURE UPDATE_CATALOGO_VICIO(pNombre IN VARCHAR2)
         AS
                 BEGIN
                 END;

       PROCEDURE UPDATE_CATALOGO_ZODIACO(pSigno IN VARCHAR2, fechaInicio IN DATE, fechaFinal IN DATE)
         AS
                 BEGIN
                 END;

       PROCEDURE UPDATE_CATALOGO_SALARIO(pRango IN VARCHAR2)
         AS
                 BEGIN
                 END;

       PROCEDURE UPDATE_CATALOGO_RELIGION(pNombre IN VARCHAR2)
         AS
                 BEGIN
                 END;

       PROCEDURE UPDATE_CATALOGO_PESO(pRango IN VARCHAR2)
         AS
                 BEGIN
                 END;

END UPDATES_CATALOGO;
