<?php

?>
<html>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    
    <meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
	<link rel="stylesheet" href="assets/css/main.css" />
	<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->	
	</head>

	<body style="background-color:#FFFFFF;color:green;font-family:verdana;font-size:14px;">
		<div id="main">
			
			<div class="box alt container">
				<section class="feature center">
					<div class="content">
						<a href="frame_catalogos.php" target="_parent">
							<img src="images/catalogo.png" alt="" width="40" height="40"/><br>Catálogos
						</a>
					</div>
				</section>

				<section class="feature rigth">			
					<div class="content">
						<a href="calendar/demos/external-dragging" target="_parent">
							<img src="images/calendario.png" alt="" width="40" height="40"/><br>Eventos
						</a>
					</div>
				</section>
				
				<section class="feature rigth">
				<div class="content">
					<a href="frame_estadisticas.php" target="_parent">
						<img src="images/estadistica.png"  alt="" width="20" height="20"/><br>Estadisticas<br>Parametros
					</a>
				</div>
			</section>	
			</div>
			
		</div>
	</body>
	

</html>
