<?php

?>

<html>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="stylesheet" href="assets/css/main.css" />
	<head>
		<title>
				Cor Bessó
		</title>
		

				<blockquote>
					<font face="avenida" size=14>Estadísticas</font>
				</blockquote>

		
	</head>

	<body>
		<div>
				<th colspan="2">
					<font face="verdana" size=5 align="center"><br>Consultas por Catálogo</font>
				</th>	
				
				<TR>
					<TD>					
						<SELECT name="rango" style="font-size:12pt">
							<OPTION VALUE="18 a 21"><font face="verdana" size=5>cat1</font></OPTION>
							<OPTION VALUE="22 a 25"><font face="verdana" size=5>cat2</font></OPTION>
							<OPTION VALUE="26 a 28"><font face="verdana" size=5>cat3</font></OPTION>
						</SELECT>
						<SELECT name="rango" style="font-size:12pt">
							<OPTION VALUE="18 a 21"><font face="verdana" size=5>va1</font></OPTION>
							<OPTION VALUE="22 a 25"><font face="verdana" size=5>val2</font></OPTION>
							<OPTION VALUE="26 a 28"><font face="verdana" size=5>val3</font></OPTION>
							<OPTION VALUE="29 a 32"><font face="verdana" size=5>val4</font></OPTION>
						</SELECT>
					</TD>
					
					<td align="center">
						<font face="verdana" size=5 align="center"><br>Cantidad:  #</font>
					</td>
					<td>
						<div class="row"><th>
					<div class="12u">
						<ul class="actions">
							<li><input type="submit" value="Consultar" /></li>
						</ul>
					</div></th>
				</div>
					</td>
				</TR>
		</div>
	</body>
</html>
