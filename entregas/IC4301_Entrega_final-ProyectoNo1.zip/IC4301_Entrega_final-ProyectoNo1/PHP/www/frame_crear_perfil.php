<?php

?>

<html>
	<meta charset="utf-8" />
	<title>Cor Besssó</title>
	
	<frameset rows="90,*" framespacing="3" frameborder="yes" border="0" bordercolor="#000000">

		<frame src="encabezado.php" name="marcosuperior" frameborder="yes" scrolling="NO">

	    	<frameset cols="150,*" framespacing="3" frameborder="yes" border="0" bordercolor="#FF9900">

	        	<frame src="menu.php" name="marcoizquierdo" scrolling="no" noresize>
	        	<frame src="crear_perfil.php" name="marcoderecho">

	      	</frameset>
	 		

	</frameset>
</html>
