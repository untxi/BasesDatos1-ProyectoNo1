<?php

?>

<html>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="stylesheet" href="assets/css/main.css" />
	<head>
		<title>
				Cor Bessó
		</title>
		
		<blockquote> 
				<blockquote>
					<font face="avenida" size=14>Catálogos</font>
				</blockquote>
		</blockquote>
		
	</head>

	<body>
		<table align="center">
			<TR>
				<TD>
					<font face="verdana" size=5>País</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="pais">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Estado Civil</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Cantidad Máxima de Hijosl</font>
				</TD>
				
				<TD>
					<INPUT type=text name="max_hijos" size=3 style="font-size:20px">

				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Altura</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="altua">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Peso</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Contextura</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Color de Piel</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Color de Ojos</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Color de Cabello</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Escolaridad</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			<TR>
				<TD>
					<font face="verdana" size=5>Idiomas</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Ocupación</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Salarios</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Deportes</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Actividades Recreativas</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Hobbies</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Vicios</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<TR>
				<TD>
					<font face="verdana" size=5>Categoría</font>
				</TD>
				
				<TD>
					<TEXTAREA rows="3" name="civil">Separe por barra /</TEXTAREA>
				</TD>
			</TR>
			
			<!-- Botón -->
				<TH COLSPAN=2>
					<INPUT type="submit" value=" Guardar " style="font-size:12pt" style='width:100px; height:50px'>
				</TH>
	
			

		</table>
	</body>
</html>
