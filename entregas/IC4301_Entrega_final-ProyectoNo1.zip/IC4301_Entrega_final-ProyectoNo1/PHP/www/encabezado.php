<?php

?>

<html>
	<meta charset="utf-8" />
	<title>CorBessó</title>
	<body style="background-color: #ffffff;color:purple;font-family:verdana;font-size:14px;">
	
		<table align="center" width=90%>
			<tr>
				<td>
					<a href="frame_resultado.php" target="_parent">
						<img src="images/logo_corbesso.png" align="center" alt="logo" width="150" height="80">
					</a>
					<font face="avenida" size=14>Cor Bessó</font>
				</td>
				<td>			
					<p align="center">
						<font face="avenida" size=14 ><a href="frame_ver_mi_perfil.php" target="_parent">User</a></font>
					</p>
				</td>
				<td>	
					<p align="right"><a href="log.php" target="_parent">
						<div>
							<img src="images/salir.png" align="center"  width="30" height="30">
						</div>

						<font face="avenida" size=8></font>Salir</font></a>
					</p>
				</td>
			</tr>
		</table>
	</body>
</html>
