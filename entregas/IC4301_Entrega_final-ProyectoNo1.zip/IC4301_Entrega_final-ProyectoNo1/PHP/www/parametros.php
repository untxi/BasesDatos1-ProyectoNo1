<?php

?>

<html>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="stylesheet" href="assets/css/main.css" />
	<head>
		<title>
				Cor Bessó
		</title>
		

				<blockquote>
					<font face="avenida" size=14>Parametros</font>
				</blockquote>

		
	</head>

	<body>
		<div>
					
				
				<TR>
					<TD>
						<font face="verdana" size=5 align="center"><br>Top Match</font>
						<input class="m-wrap placeholder-no-fix" type="text" autocomplete="off" placeholder="actual" name="topMatch"/>
					</TD>
					<TD>
						<font face="verdana" size=5 align="center"><br>Top Winks</font>
						<input class="m-wrap placeholder-no-fix" type="text" autocomplete="off" placeholder="actual" name="topMatch"/>
					</TD>
					<TD>
						<font face="verdana" size=5 align="center"><br>Mensaje Evento</font>
						<input class="m-wrap placeholder-no-fix" type="text" autocomplete="off" placeholder="'Hola, te invitamos a nuestro próximo evento en tu ciudad.\nBusca los detalles en tu perfil'" name="topMatch"/>
					</TD>
					
				</TR>
				
				
				<div class="row"><th>
					<div class="12u">
						<ul class="actions">
							<li><input type="submit" value="Guardar" /></li>
						</ul>
					</div></th>
				</div>
		</div>
	</body>
</html>

