<?php
define("HOST", "localhost/dbprueba");
//define("PORT", 3306);
define("USER", "cb");
define("PASS", "cb");
define("DB", "corbesso");
date_default_timezone_set("America/Costa_Rica");
?>
