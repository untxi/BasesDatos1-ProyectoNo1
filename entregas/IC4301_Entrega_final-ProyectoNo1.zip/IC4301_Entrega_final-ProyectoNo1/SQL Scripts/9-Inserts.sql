﻿
-- insertar catalogos
-- 
--inserts_catalogo.INSERTAR_CATALOGO_RECREATIVA('Volar Papalotes');
-- 
--inserts_catalogo.insertar_catalogo_pais('Costa Rica');
-- 
/*inserts_catalogo.INSERTAR_CATALOGO_CIUDAD('San José', 0);
inserts_catalogo.INSERTAR_CATALOGO_CIUDAD('Cartago',  0);
inserts_catalogo.INSERTAR_CATALOGO_CIUDAD('Alajuela', 0);
inserts_catalogo.INSERTAR_CATALOGO_CIUDAD('Heredia',  0);
inserts_catalogo.INSERTAR_CATALOGO_CIUDAD('Limón',    0);
inserts_catalogo.INSERTAR_CATALOGO_CIUDAD('Guanacaste', 0);
inserts_catalogo.INSERTAR_CATALOGO_CIUDAD('Puntarenas', 0);
-- */
/*inserts_catalogo.INSERTAR_CATALOGO_EDAD('18 a 21 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('22 a 25 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('26 a 28 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('29 a 32 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('33 a 36 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('37 a 40 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('41 a 44 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('45 a 50 años');
inserts_catalogo.INSERTAR_CATALOGO_EDAD('más de 50 años');
--

inserts_catalogo.INSERTAR_CATALOGO_VICIO('Fumador Adicto');
inserts_catalogo.INSERTAR_CATALOGO_VICIO('Fumador Social');
--
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Cualquiera',to_date('01/01/2000','dd/mm/yyyy'),to_date('31/12/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Aries',to_date('21/03/2000','dd/mm/yyyy'),to_date('20/04/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Tauro',to_date('21/04/2000','dd/mm/yyyy'),to_date('21/05/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Géminis',to_date('22/05/2000','dd/mm/yyyy'),to_date('21/06/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Cáncer',to_date('22/06/2000','dd/mm/yyyy'),to_date('22/07/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Leo',to_date('23/07/2000','dd/mm/yyyy'),to_date('23/08/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Virgo',to_date('24/08/2000','dd/mm/yyyy'),to_date('23/09/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Libra',to_date('24/09/2000','dd/mm/yyyy'),to_date('23/10/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Escorpión',to_date('24/10/2000','dd/mm/yyyy'),to_date('22/11/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Sagitario',to_date('23/11/2000','dd/mm/yyyy'),to_date('21/12/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Capricornio',to_date('22/12/2000','dd/mm/yyyy'),to_date('20/01/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Acuario',to_date('21/01/2000','dd/mm/yyyy'),to_date('18/02/2000','dd/mm/yyyy'));
inserts_catalogo.INSERTAR_CATALOGO_ZODIACO('Piscis',to_date('19/02/2000','dd/mm/yyyy'),to_date('20/03/2000','dd/mm/yyyy'));
--
inserts_catalogo.INSERTAR_CATALOGO_SALARIO('₡280 a ₡400 mil');
inserts_catalogo.INSERTAR_CATALOGO_SALARIO('₡400 a ₡650 mil');
inserts_catalogo.INSERTAR_CATALOGO_SALARIO('₡650 a ₡950 mil');
inserts_catalogo.INSERTAR_CATALOGO_SALARIO('₡950 a más');
--
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Ninguna');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Cristianismo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Judaísmo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Hinduismo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Bahaísmo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Islam');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Neopaganismo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Taoísmo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Sintoísmo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Budismo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Sijismo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Brahmanismo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Jainismo');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Ayyavazhi');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Wicca');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Templarios');
inserts_catalogo.INSERTAR_CATALOGO_RELIGION('Ateo');
--
inserts_catalogo.INSERTAR_CATALOGO_PESO('menos de 50 kg');
inserts_catalogo.INSERTAR_CATALOGO_PESO('50   a 60  kg');
inserts_catalogo.INSERTAR_CATALOGO_PESO('60   a 75  kg');
inserts_catalogo.INSERTAR_CATALOGO_PESO('75   a 90  kg');
inserts_catalogo.INSERTAR_CATALOGO_PESO('90   a 100 kg');
inserts_catalogo.INSERTAR_CATALOGO_PESO('100  a 130 kg');
inserts_catalogo.INSERTAR_CATALOGO_PESO('130  a 150 kg');
inserts_catalogo.INSERTAR_CATALOGO_PESO('más de 150 kg');
--
inserts_catalogo.INSERTAR_CATALOGO_ALTURA('menos de 1,5 m');
inserts_catalogo.INSERTAR_CATALOGO_ALTURA('1,5  a 1,65 m');
inserts_catalogo.INSERTAR_CATALOGO_ALTURA('1,65 a 1,75 m');
inserts_catalogo.INSERTAR_CATALOGO_ALTURA('1,75 a 1,85 m');
inserts_catalogo.INSERTAR_CATALOGO_ALTURA('1,85 a 1,95 m');
inserts_catalogo.INSERTAR_CATALOGO_ALTURA('más de 2 m');
--
inserts_catalogo.INSERTAR_CATALOGO_CCOJOS('Negro');
inserts_catalogo.INSERTAR_CATALOGO_CCOJOS('Café');
inserts_catalogo.INSERTAR_CATALOGO_CCOJOS('Verde');
inserts_catalogo.INSERTAR_CATALOGO_CCOJOS('Azul');
--
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Negro');
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Rubio');
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Castaño');
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Castaño Oscuro');
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Castaño Claro');
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Pelirojo');
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Gris');
inserts_catalogo.INSERTAR_CATALOGO_CCABELLO('Blanco');
--
inserts_catalogo.INSERTAR_CATALOGO_CONTEXTURA('Ectomorfos');
inserts_catalogo.INSERTAR_CATALOGO_CONTEXTURA('Mesomorfos');
inserts_catalogo.INSERTAR_CATALOGO_CONTEXTURA('Endomorfos');
--
inserts_catalogo.INSERTAR_CATALOGO_CPIEL('MarfilBlanca');
inserts_catalogo.INSERTAR_CATALOGO_CPIEL('Pálida');
inserts_catalogo.INSERTAR_CATALOGO_CPIEL('Pálida a beige');
inserts_catalogo.INSERTAR_CATALOGO_CPIEL('Moreno claro');
inserts_catalogo.INSERTAR_CATALOGO_CPIEL('Moreno oscuro');
--
inserts_catalogo.INSERTAR_CATALOGO_DEPORTE('Maratón');
inserts_catalogo.INSERTAR_CATALOGO_DEPORTE('Ciclismo');
--
inserts_catalogo.INSERTAR_CATALOGO_ESCOLARIDAD('Escuela');
inserts_catalogo.INSERTAR_CATALOGO_ESCOLARIDAD('Colegio');
inserts_catalogo.INSERTAR_CATALOGO_ESCOLARIDAD('Universidad');
inserts_catalogo.INSERTAR_CATALOGO_ESCOLARIDAD('Licenciatura');
inserts_catalogo.INSERTAR_CATALOGO_ESCOLARIDAD('Maestría');
inserts_catalogo.INSERTAR_CATALOGO_ESCOLARIDAD('Doctorado');
--
inserts_catalogo.INSERTAR_CATALOGO_FRECUENCIA('-3 veces semana');
inserts_catalogo.INSERTAR_CATALOGO_FRECUENCIA('3 a 5 semanal');
inserts_catalogo.INSERTAR_CATALOGO_FRECUENCIA('Diario');
--
inserts_catalogo.INSERTAR_CATALOGO_HOBBIE('Rompecabezas');
inserts_catalogo.INSERTAR_CATALOGO_HOBBIE('Juegos de Video');
--
inserts_catalogo.INSERTAR_CATALOGO_IDIOMA('Español');
inserts_catalogo.INSERTAR_CATALOGO_IDIOMA('Inglés');
inserts_catalogo.INSERTAR_CATALOGO_IDIOMA('Francés');
inserts_catalogo.INSERTAR_CATALOGO_IDIOMA('Mandarín');
--
inserts_catalogo.INSERTAR_CATALOGO_OCUPACION('Ingeniero-a');
inserts_catalogo.INSERTAR_CATALOGO_OCUPACION('Profesor-a');
inserts_catalogo.INSERTAR_CATALOGO_OCUPACION('Comerciante');
inserts_catalogo.INSERTAR_CATALOGO_OCUPACION('Pensionado');
--
inserts_catalogo.insertar_catalogo_est_civil('Soltero');
inserts_catalogo.insertar_catalogo_est_civil('Casado');
inserts_catalogo.insertar_catalogo_est_civil('Divorviado');
inserts_catalogo.insertar_catalogo_est_civil('Viudo');
inserts_catalogo.insertar_catalogo_est_civil('Unión Libre');
inserts_catalogo.insertar_catalogo_est_civil('Padre/Madre Soltero-a');
--*/

-- insertar usuario
--inserts_tablas.INSERTAR_TABLA_TIPOU('T','samarburola@gmail.com','12345678');

-- insertar persona
/*inserts_tablas.INSERTAR_TABLA_PERSONA(0,'Samantha','Arburola','León',to_date('18/02/1994','dd/mm/yyyy'),
                                      'F','C:\Users\sam\Desktop\fotosPerfil\1','Un día a la vez, el sol sandrá.',
                                      'T','T',0,'T',0,2, 0, 1,11,2, 0, 1, 1, 1, 4, 0, 1, 2);
                                      
*/

/*-- insertar de la persona a otras tablas                                      
inserts_tablas.INSERTAR_TABLA_ACTIVIDAD_P(pActividad  => 0,
                                          pPersona    => 8,
                                          pFrecuencia => 0);*/
                                          
declare
begin
  inserts_tablas.INSERTAR_TABLA_DEPORTE_P(pDeporte  => 1,
                                        pPersona    => 8,
                                        pFrecuencia => 0);                                  
end;
                                        
declare
begin
  inserts_tablas.INSERTAR_TABLA_HOBBIE_P(pHobbie     => 0,
                                       pPersona    => 8,
                                       pFrecuencia => 0);
end;



inserts_tablas.INSERTAR_TABLA_IDIOMA_P(pPersona => 8, pIdioma => 0);
inserts_tablas.INSERTAR_TABLA_IDIOMA_P(pPersona => 8, pIdioma => 1);


declare
begin
inserts_tablas.INSERTAR_TABLA_BUSCAR_P(8,1,'M','T','T',0,'T',0,2,0,1,0,3,
                                       3,2,2,1,3,0,1,3);
end;
