declare
begin
  inserts_catalogo.INSERTAR_CATALOGO_EDAD(18,21);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(22,25);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(26,29);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(30,33);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(34,37);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(38,41);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(42,45);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(46,49);
inserts_catalogo.INSERTAR_CATALOGO_EDAD(50,99);
end;

select * from edad;
