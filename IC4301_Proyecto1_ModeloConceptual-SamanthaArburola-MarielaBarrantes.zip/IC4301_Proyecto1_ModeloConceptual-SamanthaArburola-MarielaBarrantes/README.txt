 ~~ README ~~
		Cor Bess�
En la carpeta se encuentra:
	- MODELO-CONCEPTUAL-PROYECTO1.svg
	- MODELO-CONCEPTUAL-PROYECTO1.png
	- MODELO-CONCEPTUAL-PROYECTO1	 ;generado con la aplicaci�n draw.io
En el Diagrama se encuentra:
	- Modelo Conceptual
	- Simbolog�a
	- Logo de la Aplicaci�n y Logo del Desarrollador

Proyecto Desarrollado por Samantha Arburola  
			  Mariela  Barrantes IC4301 San Jos�